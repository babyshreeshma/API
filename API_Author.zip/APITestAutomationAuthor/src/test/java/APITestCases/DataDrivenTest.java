package APITestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import endpoints.AuthorEndPoints;
import io.restassured.response.Response;
import payload.AuthorModel;
import utilities.DataProviders;

public class DataDrivenTest {
	
	@Test(priority=1,dataProvider="data",dataProviderClass = DataProviders.class)
	public void testPostAuthor(String id,String idBook,String firstname,String lastname) {
		AuthorModel auth = new AuthorModel();
		auth.setId(id);
		auth.setIdBook(idBook);
		auth.setFirstname(firstname);
		auth.setLastname(lastname);
	
		Response response = AuthorEndPoints.createAuthor(auth);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);	
	}
	
	@Test(priority=2,dataProvider="AuthorId",dataProviderClass= DataProviders.class)
	public void testGetAuthorId(String id) {
		Response response = AuthorEndPoints.getAuthor1(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);	
	}
	
	@Test(priority=3,dataProvider="BookId",dataProviderClass= DataProviders.class)
	public void testGetBookId(String idBook) {
		Response response = AuthorEndPoints.getAuthor(idBook);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);	
	}
	
	@Test(priority=4,dataProvider="AuthorId",dataProviderClass= DataProviders.class)
	public void testUpdateAuthorId(String id) {
		AuthorModel auth = new AuthorModel();
		 auth.setId(id);
		 auth.setIdBook("13");
		 auth.setFirstname("Firstname updated");
		 auth.setLastname("Lastname updated");
		Response response = AuthorEndPoints.getAuthor1(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);	
	}
	
	@Test(priority=5,dataProvider="AUthorId",dataProviderClass= DataProviders.class)
	public void testdeleteAuthorId(String id) {
		
		      Response response=AuthorEndPoints.deleteAuthor(id);
		      response.then().log().all();
		      Assert.assertEquals(response.getStatusCode(),200);
		
	}

}
