package endpoints;

public class Routes {
	
	public static String baseuri="https://fakerestapi.azurewebsites.net/api/v1";
	public static String get_basepath="/Authors";
	public static String post_basepath="/Authors";
	public static String get1_basepath="/Authors/authors/books/{idBook}";
	public static String get2_basepath="/Authors/{id}";
	public static String put_basepath="/Authors/{id}";
	public static String delete_basepath="/Authors/{id}";
	

}
