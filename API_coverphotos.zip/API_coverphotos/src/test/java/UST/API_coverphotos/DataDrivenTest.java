package UST.API_coverphotos;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.main.endpoints.UserEndPoints;
import com.main.payload.UserModel;
import com.main.utilites.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DataDrivenTest {
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testPostUser(String id,String idBook,String url) {
	RestAssured.useRelaxedHTTPSValidation();
	UserModel user=new UserModel();
	user.setId(Integer.parseInt(id));
	user.setIdBook(Integer.parseInt(idBook));
	user.setUrl(url);
	
	Response response=UserEndPoints.createUser(user);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testDeleteByUserName(String id) {
		 RestAssured.useRelaxedHTTPSValidation();
	Response response=UserEndPoints.deleteUser(id);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
	}




