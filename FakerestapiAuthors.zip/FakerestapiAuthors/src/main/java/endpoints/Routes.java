package endpoints;

public class Routes {
	public static String baseuri="https://fakerestapi.azurewebsites.net/api/v1";

	public static String post_basePath="/Authors";
	public static String get_basePath1="/Authors/{id}";
	public static String get_basePath2="/Authors/authors/books/{idBook}";
	public static String delete_basePath="/Authors/{id}";
	public static String update_basePath="/Authors/{id}";

}
