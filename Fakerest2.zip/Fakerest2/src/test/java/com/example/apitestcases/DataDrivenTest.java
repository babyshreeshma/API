package com.example.apitestcases;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.example.endpoints.UserEndPoints;
import com.example.payload.UserModel;
import com.example.utilities.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;
@Listeners(com.example.utilities.ExtentReportManager.class)

public class DataDrivenTest {
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
public void testPostUser(String id,String idBook,String url) {
		RestAssured.useRelaxedHTTPSValidation();
	UserModel user=new UserModel();
	user.setId(Integer.parseInt(id));
	user.setIdBook(idBook);
	user.setUrl(url);
	
	
	Response response=UserEndPoints.createUser(user);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
}
	@Test(priority=2,dataProvider ="idss",dataProviderClass=DataProviders.class)
	public void testGetByid(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=UserEndPoints.getUser2(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=3,dataProvider ="idss",dataProviderClass=DataProviders.class)
	public void testGet1Byid(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=UserEndPoints.getUser3(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=4,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testGetUser(String id,String idBook,String url) {
			
		
		
		Response response=UserEndPoints.getUser1();
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);

}
	@Test(priority = 5,dataProvider="updates",dataProviderClass=DataProviders.class)
    public void testUpdateuserById(String id,String idBook,String url)
{
RestAssured.useRelaxedHTTPSValidation();
UserModel user=new UserModel();
user.setId(Integer.parseInt(id));
user.setIdBook(idBook);
user.setUrl(url);
Response response = UserEndPoints.updateUser(Integer.parseInt(id),user);
        response.then().log().all();
Assert.assertEquals(response.getStatusCode(),200);
}
	@Test(priority=6,dataProvider ="idss",dataProviderClass=DataProviders.class)
	public void testDeleteByUserName(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=UserEndPoints.deleteUser(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
	}
}
